package com.example.nvm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onNextActivity(View view) {
        EditText nameText = findViewById(R.id.name);
        EditText ageText = findViewById(R.id.age);
        EditText groupText = findViewById(R.id.group);
        EditText markText = findViewById(R.id.mark);
        String name = nameText.getText().toString();
        int age = Integer.parseInt(ageText.getText().toString());
        String group = groupText.getText().toString();
        int mark = Integer.parseInt(markText.getText().toString());
        Intent intent = new Intent(this, NewActivity.class);
        intent.putExtra("name", name);
        intent.putExtra("age", age);
        intent.putExtra("group", group);
        intent.putExtra("mark", mark);
        startActivity(intent);
    }

    public static final String TAG = "NovachukVM";
    @Override
    protected void onStart() {
        super.onStart();
        Log.e(TAG, "error in onStart");
        Log.w(TAG, "warning in onStart");
        Log.i("IKBO-68-23", "info in onStart");
        Log.d("IKBO-68-23", "debug in onStart");
        Log.v("IKBO-68-23", "verbose in onStart");
    }
}
